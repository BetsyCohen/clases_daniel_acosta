## Levantar los datos de internet
library(tidyverse)

mi_base <- starwars |> 
  filter(eye_color == "blue")


write_rds(mi_base,"input/mi_base_limpia.rds")
