## Script de transformacion

df <- read_rds("input/mi_base_limpia.rds")

df <- df |> 
  mutate(variable_loca = 1,
         id_persona =1:nrow(df)) 


write_rds(df,"input/base_limpia_para_informe.rds") 
